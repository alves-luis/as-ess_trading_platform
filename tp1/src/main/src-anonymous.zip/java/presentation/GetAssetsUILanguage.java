package presentation;

import java.util.List;

public interface GetAssetsUILanguage {
    String getInsertTypeofAsset();
    List<String> getTypesOfAssets();
}
