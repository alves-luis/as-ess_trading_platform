package presentation;

public interface UINegociador {
    void start();
}
