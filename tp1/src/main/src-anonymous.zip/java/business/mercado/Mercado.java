package business.mercado;

public interface Mercado extends MercadoAcao, MercadoIndice, MercadoMoeda, MercadoCommodity {
}